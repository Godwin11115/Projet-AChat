<?php

// Informations de l'API RapidAPI
$rapidapiHost = "ebay-products-search-scraper.p.rapidapi.com";
$rapidapiKey = "4aa5bcf89cmshecbfd0563dd4ac1p1d9699jsn41d29d6b156d";

// Récupérer la requête de recherche
$query = isset($_GET['query']) ? urlencode($_GET['query']) : 'xbox'; // Valeur par défaut si aucune requête n'est fournie
$page = isset($_GET['page']) ? intval($_GET['page']) : 1; // Page de résultats par défaut

// URL de l'API
$url = "https://$rapidapiHost/products?query=$query&page=$page&Item_Location=europe";

// Chemin vers le fichier cacert.pem
$cacertPath = "C:/wamp64/bin/php/cacert.pem"; // Assurez-vous que ce chemin est correct

// Initialiser cURL
$curl = curl_init();

curl_setopt_array($curl, [
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => [
        "x-rapidapi-host: $rapidapiHost",
        "x-rapidapi-key: $rapidapiKey"
    ],
    CURLOPT_CAINFO => $cacertPath, // Spécifiez le chemin vers cacert.pem
]);

// Exécuter la requête
$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

// Traitement des erreurs
if ($err) {
    echo "cURL Error #:" . $err;
    exit;
}

// Convertir la réponse JSON en tableau PHP
$data = json_decode($response, true);

// Afficher la réponse complète pour le débogage
echo '<pre>';
print_r($data);
echo '</pre>';

// Vérifier si des résultats ont été trouvés
if (isset($data['products']) && !empty($data['products'])) {
    $items = $data['products'];
    
    echo '<h2>Search Results</h2>';
    echo '<ul>';
    foreach ($items as $item) {
        $title = $item['title'] ?? 'No title';
        $price = $item['price'] ?? 'No price';
        $link = $item['link'] ?? '#';
        
        echo "<li><a href=\"$link\" target=\"_blank\">$title</a> - Price: \$$price</li>";
    }
    echo '</ul>';
} else {
    echo 'No results found.';
}
?>
